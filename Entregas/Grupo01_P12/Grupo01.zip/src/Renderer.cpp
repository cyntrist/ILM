#include "Renderer.h"

#include "glm/geometric.hpp"

Renderer::Renderer(std::shared_ptr<Film> film, std::shared_ptr<Camera> camera, std::shared_ptr<World> world)
	: _film(film), _camera(camera), _world(world)
{

}

Renderer::~Renderer()
{
}

void Renderer::Render()
{
    for (std::size_t y = 0; y < _film->GetTamY(); ++y)
    {
        for (std::size_t x = 0; x < _film->GetTamX(); ++x)
        {
            const Ray ray_primary = _camera->GetRay(x, y);
            const Color c = RayColor(ray_primary);
            _film->AddPixel(c);
        }
    }
}

Color Renderer::RayColor(const Ray& r)
{
    InfoIntersection ii;
    if (_world->GetScene()->Intersect(r, 0.001f, 100, ii))
    {
        Color color = ii.m->GetColor();

        for (auto& l : _world->GetLights())
        {
            if (ii.m->GetGlossFactor() > 0)
            {
                if (_glossCalls < _glossCallsMax)
                {
                    glm::vec3 origin = ii.p;
                    glm::vec3 dir = ii.normal;
                    dir = glm::normalize(dir);

                    Ray shadowRay(origin, glm::reflect(origin, dir));

                    _glossCalls++;
                    color += ii.m->GetGlossFactor() * RayColor(shadowRay);
                }

                _glossCalls = 0;
            }

            if (l->GetShadow())
            {
                glm::vec3 origin = ii.p;
                glm::vec3 dir = l->ShadowDir(ii.p);
                float maxDist = glm::length(dir);
                dir = glm::normalize(dir);

                Ray shadowRay(origin, dir);

                if (_world->GetScene()->Intersect(shadowRay, 0.001f, maxDist))
                {
	                // saltar a la siguiente geometria
                    continue;
                }
            }

            color += l->Shade(r, ii);
        }

        return color;
    }

    return BLACK;
    // Skybox
    /*
    glm::vec3 unit_direction = glm::normalize(r.Direction());
    float a = 0.5 * (unit_direction.y + 1.0);
    return (1.0f - a) * Color(1.0, 1.0, 1.0) + a * Color(0.5, 0.7, 1.0);
	*/
}